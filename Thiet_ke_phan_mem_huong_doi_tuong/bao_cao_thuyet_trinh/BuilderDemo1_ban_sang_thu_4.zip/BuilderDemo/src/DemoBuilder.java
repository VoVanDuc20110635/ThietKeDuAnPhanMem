import builder.CarBuilder;
import com.sun.tools.javac.Main;
import director.Director;
import product.Car;

public class DemoBuilder {
    public static void main(String[] args){
        Director ronaldo = new Director();
        CarBuilder builder = new CarBuilder();
        ronaldo.buildBugatti(builder);
        builder.id(2299)
                .model("Chiron")
                .height(150)
                .color("White")
                .weight(2000);
        System.out.println(builder.toString());

    }
}
