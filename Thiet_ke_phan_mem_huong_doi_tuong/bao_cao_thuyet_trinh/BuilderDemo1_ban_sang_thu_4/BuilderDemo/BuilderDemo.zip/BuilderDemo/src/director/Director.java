package director;

import builder.CarBuilder;

public class Director {
    public void buildBugatti(CarBuilder builder){
        builder.brand("Bugatti")
                .color("Blue")
                .nbrDoors(2)
                .height(115);
    }
}
