import builder.CarBuilder;
import com.sun.tools.javac.Main;
import director.Director;
import product.Car;

public class DemoBuilder {
    public static void main(String[] args){
        Director director = new Director();
        CarBuilder builder = new CarBuilder();
        builder.id(1123)
                .model("Chiron")
                .height(120);

        director.buildBugatti(builder);
        Car newcar = builder.build();
        System.out.println(newcar.toString());

    }
}
